Оновлені файли для Практичної роботи 2

Замінити у проєкті:
1) mountains_roads/templates/mountains_roads/base.html
2) mountains_roads/templates/mountains_roads/routes_list.html
3) mountains_roads/static/mountains_roads/css/styles.css
4) mountains_roads/static/mountains_roads/js/scripts.js

Що виправлено:
- burger-меню без inline onclick
- JS винесений у зовнішній файл
- адаптивність Mobile First
- breakpoints 480 / 768 / 1024
- сітка карток 4-3-2-1
- закриття мобільного меню по кліку
- авто-приховування повідомлень через CSS-класи
- сортування без inline onchange
